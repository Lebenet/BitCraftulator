﻿// See https://aka.ms/new-console-template for more information

using testsqltodico;
using static testsqltodico.Convert;

Console.WriteLine("Hello, World!");
PrintDictionary(TransformSqlToDictionary("building_data"), "buildings");

